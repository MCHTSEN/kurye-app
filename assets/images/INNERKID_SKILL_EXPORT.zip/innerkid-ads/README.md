# İnnerkid Ads Skill

## Kurulum
Bu klasörü şuraya koy:
  ~/.openclaw/skills/innerkid-ads/

Scriptleri şuraya koy:
  /workspace/innerkid/

## Dosyalar
- SKILL.md          → OpenClaw skill tanımı
- innerkid_ads.py   → Günlük otomasyon (5 UGC + 15 slideshow)
- test_run.py       → Test scripti (2 UGC + 2 slideshow)
- ugc_batch.py      → 5 avatar UGC toplu üretim

## API
FAL_KEY gerekli → fal.ai üzerinden:
  - veed/avatars/text-to-video  (UGC)
  - fal-ai/gpt-image-1.5        (görseller)
  - fal-ai/workflow-utilities/auto-subtitle (altyazı)
