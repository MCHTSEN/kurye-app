---
name: innerkid-ads
description: İnnerkid TikTok reklam otomasyonu. Her gün saat 11:00 İstanbul saatinde çalışır. 5 UGC avatar videosu (Emily, Elena, Jasmine, Marcus, Mira — çocuk psikoloğu karakterleri) ve 15 slideshow klasörü (her birinde 4 görsel, toplamda 60 görsel) üretir. UGC için fal.ai veed/avatars/text-to-video, görseller için fal.ai gpt-image-1.5 kullanır. Tüm içerik 9:16 dikey formatta, İngilizce, ABD pazarı için. Viral TikTok hook'larıyla ebeveynleri hedefler. Sonuçlar /workspace/innerkid/output/DD.MM.YYYY Videoları/ klasörüne kaydedilir. Use when: user asks to run, test, or trigger the İnnerkid ad automation, OR when the daily cron fires.
---

# İnnerkid Ads Skill

## Ana Script
`/workspace/innerkid/innerkid_ads.py`

## Çalıştırma
```bash
FAL_KEY="d4347a5d-fa82-4341-b51a-8a3466d9716a:0febfe10e096958b8a17f7cc7007d6c6" \
  python3 /workspace/innerkid/innerkid_ads.py
```

## Çıktı Yapısı
```
/workspace/innerkid/output/DD.MM.YYYY Videoları/
├── UGC Videos/
│   ├── Emily/       → emily_ugc.mp4 + script.txt + subtitles.srt + metadata.json
│   ├── Elena/
│   ├── Jasmine/
│   ├── Marcus/
│   └── Mira/
├── 01. Slideshow — Child_Drawing_Emotions/  → image_01.png … image_04.png + metadata.json
├── 02. Slideshow — Parent_Child_Connection/
│   └── ... (15 slideshow toplam)
└── daily_report.md
```

## API Endpoints (fal.ai)
- UGC Video: `veed/avatars/text-to-video` — $0.35/dakika
- Görsel: `fal-ai/gpt-image-1.5` — medium quality, 1024x1536

## Önemli Notlar
- Tüm içerik İngilizce, US pazarı
- Avatar karakterler: çocuk psikoloğu kimliğiyle konuşur
- Hook'lar viral TikTok formatında (curiosity gap, authority, pattern interrupt)
- **Altyazı burn-in:** `fal-ai/workflow-utilities/auto-subtitle` ile otomatik
  - Font: Montserrat Bold, size 90
  - Renk: beyaz yazı + kalın siyah stroke (TikTok klasik)
  - Karaoke highlight: sarı (aktif kelime)
  - Pozisyon: bottom, 3 kelime/segment
  - Son video: `<isim>_ugc.mp4` (altyazı burn-in edilmiş)
- SRT backup dosyaları da `subtitles.srt` olarak kaydedilir
