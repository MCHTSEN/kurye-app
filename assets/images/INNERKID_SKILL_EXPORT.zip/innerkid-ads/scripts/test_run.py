#!/usr/bin/env python3
"""İnnerkid TEST RUN — 2 UGC + 2 Slideshow (parallel submit, correct poll URLs)"""
import json, time, datetime, urllib.request
from pathlib import Path

FAL_KEY = "d4347a5d-fa82-4341-b51a-8a3466d9716a:0febfe10e096958b8a17f7cc7007d6c6"
TODAY   = datetime.date.today()
OUT     = Path(f"/workspace/innerkid/output/TEST_{TODAY.strftime('%d.%m.%Y')}")
OUT.mkdir(parents=True, exist_ok=True)

# ── HTTP helpers ──────────────────────────────────────────────────────────────
def fal_http(method, url, body=None):
    data = json.dumps(body).encode() if body else None
    req  = urllib.request.Request(url, data=data, headers={
        "Authorization": f"Key {FAL_KEY}",
        "Content-Type":  "application/json",
    }, method=method)
    with urllib.request.urlopen(req, timeout=90) as r:
        return json.loads(r.read().decode())

def submit(endpoint, payload):
    """Submit to fal.ai queue. Returns dict with request_id, status_url, response_url."""
    r = fal_http("POST", f"https://queue.fal.run/{endpoint}", payload)
    print(f"    ↳ queued | {r['request_id']}")
    return {"request_id": r["request_id"], "status_url": r["status_url"], "response_url": r["response_url"]}

def poll(jm, max_wait=900):
    """Poll using status_url/response_url from submit result."""
    start = time.time()
    while time.time() - start < max_wait:
        st = fal_http("GET", jm["status_url"])
        status = st.get("status", "")
        if status == "COMPLETED":
            return fal_http("GET", jm["response_url"])
        elif status in ("FAILED", "CANCELLED"):
            raise RuntimeError(f"{jm['request_id']} → {status}")
        print(f"    ↳ {status}… ({int(time.time()-start)}s)")
        time.sleep(10)
    raise TimeoutError(f"timeout: {jm['request_id']}")

def download(url, dest):
    dest.parent.mkdir(parents=True, exist_ok=True)
    req = urllib.request.Request(url, headers={"User-Agent": "innerkid/1.0"})
    with urllib.request.urlopen(req, timeout=180) as r, open(dest, "wb") as f:
        while chunk := r.read(8192): f.write(chunk)
    print(f"    ✅ {dest.name}  ({dest.stat().st_size // 1024} KB)")

# ── Content ───────────────────────────────────────────────────────────────────
AVATARS = [
    {"name": "Emily",  "id": "emily_vertical_primary"},
    {"name": "Marcus", "id": "marcus_vertical_primary"},
]

SCRIPTS = [
    """I've worked with hundreds of kids — and this drawing told me everything about how your child is feeling right now.

My name is Emily. I'm a child psychologist, and what I'm about to share with you is something most parents never realize.

When a child draws their family, pay attention to where they place themselves. If they draw themselves small, or far from the others — that's not random. That's your child telling you something they don't have words for yet.

Children speak through art long before they can articulate their emotions.

That's exactly why I recommend Innerkid to every parent I work with. You upload your child's drawing, and the AI instantly tells you what it means — their emotional state, what they're trying to say, and what you can do right now as a parent.

Download Innerkid — the app that reads your child's drawings — link in bio.""",

    """Your child's drawing is trying to tell you something. Most parents miss it completely.

I'm Marcus, child psychologist.

Here's something that stopped a parent in my office cold last week: she showed me her son's drawing — a big house, a big dog, and two tiny people in the corner. She thought it was cute. I saw a child who felt small and overlooked in his own home.

That's what years of training teaches you to see. But you don't need years of training anymore.

Innerkid does this analysis for you — instantly. Every color, every figure, every detail decoded. Upload the drawing, get the insight, know exactly how to show up for your child today.

Download Innerkid. Link in bio.""",
]

SLIDESHOW_THEMES = [
    {
        "name": "Child_Drawing_Emotions",
        "prompts": [
            "Photorealistic, 9:16 vertical portrait, extreme close-up of a young child's hands holding bright crayons drawing on white paper, warm golden sunlight from window, shallow depth of field, Leica documentary photography, ultra sharp detail, emotionally resonant",
            "Photorealistic, 9:16 vertical portrait, beautiful young mother kneeling at eye level with her 5-year-old daughter, both smiling, daughter holding up a colorful drawing, warm afternoon light, authentic candid moment, Sony A7 full frame, bokeh background",
            "Photorealistic, 9:16 vertical portrait, child's crayon drawing of a family — two tall figures and one tiny figure far in the corner — bright colors on white paper, flat-lay on wooden table, warm natural light, artistic composition",
            "Realistic product photography, 9:16 vertical portrait, iPhone 15 Pro on white marble showing a clean app interface with a child's colorful drawing and AI emotional analysis report below, professional studio lighting, sharp focus",
        ],
    },
    {
        "name": "Parent_Child_Connection",
        "prompts": [
            "Photorealistic, 9:16 vertical portrait, worried yet loving mother sitting at kitchen table staring thoughtfully at her child's drawing, soft dramatic window light, authentic emotional expression, cinematic depth of field, Canon R5",
            "Photorealistic, 9:16 vertical portrait, breakthrough moment — mother on couch pressing hand to heart while reading phone, tears of relief, warm lamp light, deeply emotional and authentic, documentary style",
            "Photorealistic, 9:16 vertical portrait, child drawing a storm with dark swirling clouds and lightning bolts in heavy black and blue crayon — emotionally expressive art, dramatic side lighting, thought-provoking and powerful",
            "Photorealistic, 9:16 vertical portrait, family of three hugging tightly in warm golden hour sunlight — father, mother, young child — genuine happiness and deep connection, authentic candid, beautiful bokeh",
        ],
    },
]

# ── MAIN ──────────────────────────────────────────────────────────────────────
print("\n🚀 İNNERKID TEST RUN  —  2 UGC + 2 Slideshow (8 images)")
print(f"📁 {OUT}\n")

# ─ 1. Submit everything in parallel ──────────────────────────────────────────
print("="*55 + "\n📤 PARALLEL SUBMIT\n" + "="*55)
jobs = []

for i, avatar in enumerate(AVATARS):
    folder = OUT / "UGC" / avatar["name"]
    folder.mkdir(parents=True, exist_ok=True)
    (folder / "script.txt").write_text(SCRIPTS[i], encoding="utf-8")
    print(f"\n🎭 UGC: {avatar['name']}")
    jm = submit("veed/avatars/text-to-video", {"avatar_id": avatar["id"], "text": SCRIPTS[i]})
    jobs.append({"type": "ugc", "avatar": avatar, "jm": jm, "folder": folder, "idx": i})

for s, theme in enumerate(SLIDESHOW_THEMES):
    folder = OUT / f"{s+1:02d}. Slideshow — {theme['name']}"
    folder.mkdir(parents=True, exist_ok=True)
    print(f"\n🖼️  Slideshow {s+1}: {theme['name']}")
    for p, prompt in enumerate(theme["prompts"]):
        print(f"  [{p+1}/4]")
        jm = submit("fal-ai/gpt-image-1.5", {
            "prompt": prompt,
            "image_size": "1024x1536",
            "quality": "high",
            "output_format": "png",
            "num_images": 1,
        })
        jobs.append({
            "type": "img", "jm": jm, "s_num": s+1, "p_num": p+1,
            "dest": folder / f"image_{p+1:02d}.png",
            "folder": folder, "theme": theme["name"],
        })
        time.sleep(0.3)

print(f"\n✅ {len(jobs)} jobs submitted!\n")

# ─ 2. Poll images (fast, ~30s each) ──────────────────────────────────────────
print("="*55 + "\n⏳ POLLING IMAGES\n" + "="*55)
for job in [j for j in jobs if j["type"] == "img"]:
    print(f"\n🖼️  Slideshow {job['s_num']} / img {job['p_num']}")
    try:
        result = poll(job["jm"], max_wait=300)
        download(result["images"][0]["url"], job["dest"])
    except Exception as e:
        print(f"    ❌ {e}")

# ─ 3. Poll UGC → subtitle burn-in ────────────────────────────────────────────
print("\n" + "="*55 + "\n⏳ POLLING UGC + SUBTITLES\n" + "="*55)
for job in [j for j in jobs if j["type"] == "ugc"]:
    name = job["avatar"]["name"]
    print(f"\n🎭 {name}")
    try:
        result  = poll(job["jm"], max_wait=900)
        raw_url = result["video"]["url"]
        raw_mp4 = job["folder"] / f"{name.lower()}_raw.mp4"
        download(raw_url, raw_mp4)

        print(f"  🔤 Subtitle burn-in…")
        sub_jm = submit("fal-ai/workflow-utilities/auto-subtitle", {
            "video_url":          raw_url,
            "language":           "en",
            "font_name":          "Montserrat",
            "font_size":          90,
            "font_weight":        "bold",
            "font_color":         "white",
            "highlight_color":    "yellow",
            "stroke_width":       4,
            "stroke_color":       "black",
            "background_color":   "none",
            "position":           "bottom",
            "y_offset":           80,
            "words_per_subtitle": 3,
            "enable_animation":   True,
        })
        sub_res = poll(sub_jm, max_wait=600)
        final   = job["folder"] / f"{name.lower()}_final.mp4"
        download(sub_res["video"]["url"], final)
        raw_mp4.unlink(missing_ok=True)

        (job["folder"] / "metadata.json").write_text(json.dumps({
            "avatar":    name,
            "subtitles": "Montserrat Bold 90px, white + black stroke 4px, yellow karaoke highlight",
            "date":      TODAY.strftime("%d.%m.%Y"),
            "hashtags":  "#childpsychology #parenting #childdevelopment #innerkid #momtok #kidsdrawing",
        }, ensure_ascii=False, indent=2), encoding="utf-8")

    except Exception as e:
        print(f"    ❌ {e}")

# ─ Final summary ──────────────────────────────────────────────────────────────
print("\n" + "✅ "*20)
print("  TEST COMPLETE!")
print(f"  📁 {OUT}")
for p in sorted(OUT.rglob("*")):
    if p.is_file():
        print(f"     {p.relative_to(OUT)}  ({p.stat().st_size//1024}KB)")
print("✅ "*20)
