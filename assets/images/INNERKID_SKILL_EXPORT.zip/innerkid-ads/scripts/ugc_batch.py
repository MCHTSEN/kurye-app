#!/usr/bin/env python3
"""
İnnerkid UGC Batch — 5 avatar, 5 farklı script, 30-40sn, paralel submit
"""
import json, time, datetime, urllib.request, zipfile, os
from pathlib import Path

FAL_KEY = "d4347a5d-fa82-4341-b51a-8a3466d9716a:0febfe10e096958b8a17f7cc7007d6c6"
OUT = Path("/workspace/innerkid/output/ugc_batch_1")
OUT.mkdir(parents=True, exist_ok=True)

def fal_http(method, url, body=None):
    data = json.dumps(body).encode() if body else None
    req  = urllib.request.Request(url, data=data, headers={
        "Authorization": f"Key {FAL_KEY}",
        "Content-Type":  "application/json",
    }, method=method)
    with urllib.request.urlopen(req, timeout=90) as r:
        return json.loads(r.read().decode())

def submit(endpoint, payload):
    r = fal_http("POST", f"https://queue.fal.run/{endpoint}", payload)
    print(f"    ↳ queued | {r['request_id']}")
    return {"request_id": r["request_id"], "status_url": r["status_url"], "response_url": r["response_url"]}

def poll(jm, max_wait=900):
    start = time.time()
    while time.time() - start < max_wait:
        st = fal_http("GET", jm["status_url"])
        status = st.get("status", "")
        if status == "COMPLETED":
            return fal_http("GET", jm["response_url"])
        elif status in ("FAILED", "CANCELLED"):
            raise RuntimeError(f"{jm['request_id']} → {status}")
        print(f"    ↳ {status}… ({int(time.time()-start)}s)")
        time.sleep(10)
    raise TimeoutError(f"timeout: {jm['request_id']}")

def download(url, dest):
    dest.parent.mkdir(parents=True, exist_ok=True)
    req = urllib.request.Request(url, headers={"User-Agent": "innerkid/1.0"})
    with urllib.request.urlopen(req, timeout=180) as r, open(dest, "wb") as f:
        while chunk := r.read(8192): f.write(chunk)
    print(f"    ✅ {dest.name}  ({dest.stat().st_size // 1024} KB)")

# ── SCRIPTS (30-40 sn = ~80-100 kelime) ─────────────────────────────────────
AVATARS = [
    {
        "name": "Emily",
        "id": "emily_vertical_primary",
        "hook_style": "Confession + Authority",
        "script": """I'm a child psychologist — and I'm going to say something most parents aren't ready to hear.

When your child hands you a drawing, your first instinct is to say 'wow, amazing!' and stick it on the fridge.

But that drawing is a message. And most parents never read it.

The way a child draws themselves — their size, their position, the colors they use — it all reflects what's happening inside them emotionally. Things they can't say out loud yet.

I've had parents cry in my office when they finally understood what their child had been trying to tell them for months.

Your child is talking to you through every drawing.

Innerkid decodes it in seconds. Download it — link in bio."""
    },
    {
        "name": "Elena",
        "id": "elena_vertical_primary",
        "hook_style": "Story + Twist",
        "script": """A mom walked into my office last week holding her daughter's drawing. She said, 'I think she's fine. She seems happy.'

I looked at the drawing. The daughter had drawn herself completely alone — no family around her, no color, just a tiny figure in the corner of the page.

I asked the mom, 'Does she ever say she feels lonely?' The mom went quiet.

Children don't always have words for what they feel. But they always have crayons.

I'm Elena, child psychologist. And Innerkid is the tool I recommend to every parent who wants to truly understand their child.

Upload their drawing. Get the answer. It takes ten seconds. Link in bio."""
    },
    {
        "name": "Jasmine",
        "id": "jasmine_vertical_primary",
        "hook_style": "Pattern Interrupt + Energy",
        "script": """Stop. Before you hang that drawing on the fridge — watch this.

I'm Jasmine, child psychologist, and I need you to look at your child's artwork differently starting today.

See the colors they chose? That's emotional data. See where they drew themselves in the family? That's how safe they feel. See what they left out of the picture? That's what's bothering them.

You don't need years of training to understand this anymore.

Innerkid analyzes your child's drawings using AI and gives you real psychological insights in seconds.

Download it. It's free. Link in bio. Your child has been trying to tell you something."""
    },
    {
        "name": "Marcus",
        "id": "marcus_vertical_primary",
        "hook_style": "Scientific + Direct",
        "script": """Research shows children begin expressing emotions through drawing before they develop the language to verbalize them.

I'm Marcus, child psychologist. And in my practice, I use children's artwork as a diagnostic window — because it doesn't lie.

Dark colors, isolated figures, missing family members, disproportionate sizing — these are not random choices. They are a child's emotional signature.

Most parents look at these drawings and see art. I see data.

Innerkid gives every parent access to that same level of insight — instantly, on their phone.

Upload your child's drawing today. See what they've been trying to tell you. Link in bio."""
    },
    {
        "name": "Mira",
        "id": "mira_vertical_primary",
        "hook_style": "Relatable + Emotional",
        "script": """Okay so my nephew drew a picture of our family last month. Everyone was smiling, the sun was out — it looked adorable.

But when I looked closer, I noticed he drew himself standing behind everyone else, slightly apart.

As a child psychologist, that detail hit me. He was telling us something we hadn't noticed.

We had a conversation with him that night — and he opened up about things he'd been holding in for weeks.

One drawing changed everything.

That's why I love Innerkid. It helps parents see what their kids are actually saying — not just what they draw on the surface.

Download it. Link in bio. Your child is waiting to be understood."""
    },
]

# ── SUBMIT ALL ──────────────────────────────────────────────────────────────
print("\n🚀 İNNERKID UGC BATCH — 5 Avatars")
print(f"📁 Output: {OUT}\n")
print("="*55 + "\n📤 SUBMITTING...\n" + "="*55)

jobs = []
for av in AVATARS:
    folder = OUT / av["name"]
    folder.mkdir(exist_ok=True)
    (folder / "script.txt").write_text(
        f"HOOK STYLE: {av['hook_style']}\n\nSCRIPT:\n{av['script']}", encoding="utf-8"
    )
    print(f"\n🎭 {av['name']} ({av['hook_style']})")
    jm = submit("veed/avatars/text-to-video", {
        "avatar_id": av["id"],
        "text": av["script"],
    })
    jobs.append({**av, "jm": jm, "folder": folder})

print(f"\n✅ 5 jobs submitted! Polling...\n")

# ── POLL + SUBTITLE ─────────────────────────────────────────────────────────
print("="*55 + "\n⏳ POLLING + SUBTITLES\n" + "="*55)

for job in jobs:
    name = job["name"]
    print(f"\n🎭 {name}")
    try:
        result  = poll(job["jm"], max_wait=900)
        raw_url = result["video"]["url"]
        raw_mp4 = job["folder"] / f"{name.lower()}_raw.mp4"
        download(raw_url, raw_mp4)

        print(f"  🔤 Adding subtitles...")
        sub_jm = submit("fal-ai/workflow-utilities/auto-subtitle", {
            "video_url":          raw_url,
            "language":           "en",
            "font_name":          "Montserrat",
            "font_size":          75,
            "font_weight":        "bold",
            "font_color":         "white",
            "highlight_color":    "yellow",
            "stroke_width":       4,
            "stroke_color":       "black",
            "background_color":   "none",
            "position":           "center",
            "words_per_subtitle": 3,
            "enable_animation":   True,
        })
        sub_res = poll(sub_jm, max_wait=600)
        final   = job["folder"] / f"{name.lower()}_final.mp4"
        download(sub_res["video"]["url"], final)
        raw_mp4.unlink(missing_ok=True)

        (job["folder"] / "metadata.json").write_text(json.dumps({
            "avatar":     name,
            "hook_style": job["hook_style"],
            "date":       datetime.date.today().strftime("%d.%m.%Y"),
            "hashtags":   "#childpsychology #parenting #childdevelopment #innerkid #momtok #kidsdrawing #emotionalintelligence",
        }, ensure_ascii=False, indent=2), encoding="utf-8")

    except Exception as e:
        print(f"  ❌ {name}: {e}")

# ── ZIP ─────────────────────────────────────────────────────────────────────
print("\n" + "="*55 + "\n📦 ZIPPING...\n" + "="*55)
zip_path = "/workspace/innerkid/output/ugc_batch_1/INNERKID_UGC_5videos.zip"
with zipfile.ZipFile(zip_path, "w", zipfile.ZIP_DEFLATED) as z:
    for p in sorted(OUT.rglob("*")):
        if p.is_file() and p.suffix in (".mp4", ".txt", ".json"):
            z.write(p, p.relative_to(OUT))
            print(f"  + {p.relative_to(OUT)}")

print(f"\n✅ ZIP: {os.path.getsize(zip_path)//1024} KB")
print(f"📁 {zip_path}")
