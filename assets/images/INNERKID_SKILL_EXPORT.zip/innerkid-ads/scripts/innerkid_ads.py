#!/usr/bin/env python3
"""
İnnerkid TikTok Ad Automation System
=====================================
Günlük çalışır, her gün şunları üretir:
  - 5 UGC avatar videosu (Emily, Elena, Jasmine, Marcus, Mira) — fal.ai veed/avatars/text-to-video
  - 15 Slideshow klasörü, her birinde 4 görsel (60 görsel toplam) — fal.ai gpt-image-1.5

Çıktı klasörü: /workspace/innerkid/output/DD.MM.YYYY Videoları/
"""

import os
import sys
import json
import time
import random
import datetime
import urllib.request
import urllib.error
from pathlib import Path

# ── CONFIG ───────────────────────────────────────────────────────────────────
FAL_KEY = os.environ.get("FAL_KEY", "d4347a5d-fa82-4341-b51a-8a3466d9716a:0febfe10e096958b8a17f7cc7007d6c6")

TODAY     = datetime.date.today()
DATE_LABEL = TODAY.strftime("%d.%m.%Y")
OUTPUT_ROOT = Path(f"/workspace/innerkid/output/{DATE_LABEL} Videoları")

# ── AVATARS ───────────────────────────────────────────────────────────────────
AVATARS = [
    {"name": "Emily",   "id": "emily_vertical_primary"},
    {"name": "Elena",   "id": "elena_vertical_primary"},
    {"name": "Jasmine", "id": "jasmine_vertical_primary"},
    {"name": "Marcus",  "id": "marcus_vertical_primary"},
    {"name": "Mira",    "id": "mira_vertical_primary"},
]

# ── VIRAL HOOKS (ebeveyn + çocuk psikolojisi odaklı) ─────────────────────────
HOOKS_POOL = [
    "I've worked with hundreds of kids — and this drawing told me everything about how your child is feeling right now.",
    "Your child's drawing is trying to tell you something. Most parents miss it completely.",
    "Stop ignoring the signs hidden inside your child's artwork.",
    "As a child psychologist, this is the one thing I wish every parent knew about their child's drawings.",
    "If your child draws THIS — you need to know what it means before tomorrow.",
    "I analyzed over 10,000 children's drawings. Here's what yours is hiding.",
    "Every color your child picks has a meaning. Are you paying attention?",
    "Most parents look at their child's drawing and see art. I see a window into their mind.",
    "This one detail in your child's drawing could change how you parent them forever.",
    "The house your child draws is not just a house. A child psychologist explains.",
    "I told this to a mom last week and she cried — because it was exactly what her child was feeling.",
    "Your child is trying to communicate with you through every drawing they make.",
    "3 signs in your child's drawing that mean they need more emotional support right now.",
    "Before you hang that drawing on the fridge — watch this.",
    "What does it mean when a child draws themselves very small? I'll show you.",
    "Raise your hand if you've never thought to analyze your child's drawings. You're not alone.",
    "The colors your child avoids are just as important as the ones they use.",
    "I became a child psychologist because of a drawing. Let me tell you the story.",
    "No one told me this before I had kids — but a drawing can reveal everything.",
    "What your child draws in the next 5 minutes can reveal their deepest emotions.",
]

# ── AVATAR SCRIPTS ─────────────────────────────────────────────────────────────
def generate_avatar_script(avatar_name: str, hook: str) -> str:
    cta = "Download Innerkid — the app that reads your child's drawings — link in bio."
    scripts = [
        f"""{hook}

My name is {avatar_name}. I'm a child psychologist, and this is something I see every single day in my practice.

When a child draws their family, pay attention to where they place themselves. If they're far from everyone else, that's not a coincidence. Children express through art what they can't say in words.

That's exactly why I recommend Innerkid to every parent I work with. You upload your child's drawing, and the AI instantly tells you what it means — their emotional state, what they're trying to say, and what you can do right now as a parent.

{cta}""",

        f"""{hook}

Hi, I'm {avatar_name} — child psychologist.

Here's the truth: children process emotions through drawing long before they can verbalize them. When you understand what's on that paper, you understand your child on a completely different level.

Innerkid uses AI to decode your child's artwork in seconds. Colors, shapes, figures — everything analyzed, everything explained.

{cta}""",

        f"""{hook}

I'm {avatar_name}, and in over a decade of child psychology practice, the one tool parents always wish they had is a way to truly understand what their child is feeling.

That tool now exists. It's called Innerkid. You take a photo of your child's drawing, and within seconds you get a full emotional analysis — plus daily drawing challenges designed to help your child grow.

{cta}""",

        f"""{hook}

As a child psychologist — I'm {avatar_name} — I can tell you that a drawing is never just a drawing.

The size of the figures, the colors chosen, what's included and what's left out — all of it carries emotional meaning. And now there's an app that does this analysis for you, instantly.

Innerkid has genuinely changed the way parents connect with their kids.

{cta}""",

        f"""{hook}

{avatar_name} here, child psychologist.

I've spent years studying children's artwork, and what I can tell you is this — your child is speaking to you through every line they draw. Most parents just don't know how to listen.

Innerkid teaches you how. Upload the drawing, get the analysis, understand your child better than ever before.

{cta}""",
    ]
    return random.choice(scripts)


# ── SLIDESHOW THEMES & PROMPTS ─────────────────────────────────────────────────
SLIDESHOW_THEMES = [
    {
        "theme": "Child_Drawing_Emotions",
        "prompts": [
            "Photorealistic, 9:16 vertical portrait, close-up of a child's colorful crayon drawing on white paper, warm soft natural lighting, shallow bokeh, shot on iPhone 15 Pro, photojournalistic style, no text overlay, authentic",
            "Photorealistic, 9:16 vertical portrait, loving mother gently holding her young child's artwork and smiling warmly, soft diffused indoor light, cozy living room bokeh background, candid documentary style, shot on iPhone",
            "Photorealistic, 9:16 vertical portrait, extreme close-up of a small child's hands gripping bright crayons, drawing on white paper, golden warm light, shallow depth of field, heartfelt and authentic",
            "Realistic app mockup photo, 9:16 vertical portrait, iPhone screen showing a clean child-drawing-analysis app — colorful kid drawing on left, emotional AI report on right, white minimal UI, professional product photography",
        ]
    },
    {
        "theme": "Parent_Child_Connection",
        "prompts": [
            "Photorealistic, 9:16 vertical portrait, happy mother kneeling beside her 5-year-old daughter who is drawing on paper on the floor, warm afternoon window light, genuine candid moment, shot on iPhone",
            "Photorealistic, 9:16 vertical portrait, child's colorful drawing of a family with a house and sun, taped to a white refrigerator door, warm kitchen light, cozy domestic scene",
            "Photorealistic, 9:16 vertical portrait, close-up of a child's hand-drawn family — stick figures holding hands — bright red and yellow and blue crayons visible beside the paper, natural light",
            "Photorealistic, 9:16 vertical portrait, father sitting at kitchen table watching proudly as his young daughter draws, soft golden hour light, genuine heartwarming family moment",
        ]
    },
    {
        "theme": "Emotional_Intelligence",
        "prompts": [
            "Photorealistic, 9:16 vertical portrait, a child sitting cross-legged on a hardwood floor, completely absorbed in drawing in a sketchbook, soft natural window light, cozy peaceful atmosphere",
            "Photorealistic, 9:16 vertical portrait, close-up of a child's drawing showing a tiny figure alone in a corner of a large white page — emotionally symbolic, natural daylight, thought-provoking composition",
            "Photorealistic, 9:16 vertical portrait, concerned mother gently sitting next to her child at a table, looking carefully at the child's drawing, warm soft dramatic lighting, authentic emotional moment",
            "Photorealistic, 9:16 vertical portrait, parent sitting at a wooden desk reading a child psychology report on their phone, warm desk lamp, thoughtful expression, home office setting, evening light",
        ]
    },
    {
        "theme": "App_Feature_Showcase",
        "prompts": [
            "Realistic product photo, 9:16 vertical portrait, iPhone 15 Pro on white table showing colorful child-drawing analysis app with emotional report below the artwork, clean professional tech photography, bright studio light",
            "Photorealistic, 9:16 vertical portrait, smiling young mother looking at her phone screen while a child plays in the soft-focus background, warm afternoon home lighting, authentic lifestyle",
            "Photorealistic, 9:16 vertical portrait, child excitedly holding up a colorful drawing they just finished, big smile, bright natural backyard light, joyful and energetic composition",
            "Realistic app notification mockup, 9:16 vertical portrait, iPhone lock screen showing notification: 'Innerkid: Your child drew something important today' — dark mode, clean modern UI design",
        ]
    },
    {
        "theme": "Child_Development",
        "prompts": [
            "Photorealistic, 9:16 vertical portrait, young child aged 4–6 at a colorful art table surrounded by crayons, focused creative expression, bright warm educational environment",
            "Photorealistic, 9:16 vertical portrait, flat lay overhead shot of many children's drawings spread across a white table — houses, suns, stick figures, animals — warm soft light, creative abundance",
            "Photorealistic, 9:16 vertical portrait, child's drawing showing a very small figure drawn in the far corner of a large white page, stark white background, psychologically meaningful, natural light",
            "Photorealistic, 9:16 vertical portrait, parent and child high-fiving after completing a drawing together, both laughing, bright natural light, joyful authentic energy",
        ]
    },
    {
        "theme": "Before_After_Transformation",
        "prompts": [
            "Photorealistic, 9:16 vertical portrait, worried mother staring at her child's drawing with a puzzled and concerned expression, soft dramatic side lighting, authentic emotion, kitchen table setting",
            "Photorealistic, 9:16 vertical portrait, relieved and happy mother covering her mouth with her hand after reading something meaningful on her phone, breakthrough emotional moment, warm soft lighting",
            "Photorealistic, 9:16 vertical portrait, child drawing a big bright yellow sun with a wide smile, cheerful and full of life, natural light flooding the room, pure joy",
            "Photorealistic, 9:16 vertical portrait, family of three embracing warmly — child between smiling parents — golden sunset backyard light, genuine happiness and connection",
        ]
    },
    {
        "theme": "Psychology_Expert_Authority",
        "prompts": [
            "Photorealistic, 9:16 vertical portrait, professional child psychologist at a warm wooden desk reviewing colorful children's drawings, bookshelves in background, trustworthy and expert atmosphere, soft lamp light",
            "Photorealistic, 9:16 vertical portrait, close-up of professional hands pointing to specific details in a child's drawing on a clipboard, analytical and clinical yet warm setting",
            "Photorealistic, 9:16 vertical portrait, child's drawing showing a storm with dark clouds and lightning bolts — dramatically expressive crayon art on white paper, high contrast lighting, emotionally powerful",
            "Photorealistic, 9:16 vertical portrait, open book about children's art therapy on a wooden desk, warm desk lamp, reading glasses beside it, credible academic atmosphere",
        ]
    },
    {
        "theme": "Social_Proof",
        "prompts": [
            "Realistic phone screenshot mockup, 9:16 vertical portrait, App Store page showing 5-star review: 'This app helped me understand my son like never before' — clean white background, authentic review UI",
            "Photorealistic, 9:16 vertical portrait, group of three young moms at a bright cafe table, one holding up her phone showing a child drawing analysis, others leaning in, warm cafe lighting, authentic social moment",
            "Photorealistic, 9:16 vertical portrait, confident child proudly holding up their finished drawing like a trophy, big smile, colorful artwork, warm natural light, joyful",
            "Realistic app notification mockup, 9:16 vertical portrait, phone screen showing: 'Daily Challenge: Draw your dream house today! 🏠' — clean colorful UI, white background, Innerkid app style",
        ]
    },
    {
        "theme": "Color_Psychology",
        "prompts": [
            "Photorealistic, 9:16 vertical portrait, a child's drawing using only dark colors — heavy black and dark blue purple crayon marks on white paper — moody and thought-provoking, dramatic natural light",
            "Photorealistic, 9:16 vertical portrait, child's drawing bursting with bright yellows and reds and greens — energetic joyful artwork, rainbow crayons scattered around the page, warm cheerful light",
            "Photorealistic, 9:16 vertical portrait, flat lay of two side-by-side child drawings — one in dark heavy tones, one in light cheerful colors — showing emotional contrast, warm overhead light, wooden table",
            "Photorealistic, 9:16 vertical portrait, close-up of a young child's hand pausing between a black crayon and a bright yellow crayon — decision moment, soft focused lighting, emotionally symbolic",
        ]
    },
    {
        "theme": "Daily_Challenge_Feature",
        "prompts": [
            "Photorealistic, 9:16 vertical portrait, child drawing a house with extreme concentration — tongue peeking out, crayons spread wide, warm home lighting, adorable and authentic",
            "Photorealistic, 9:16 vertical portrait, corkboard on a wall covered in a child's weekly drawings — a progression of houses, cars, animals, family — cozy home, warm afternoon light",
            "Realistic app mockup, 9:16 vertical portrait, phone screen showing: 'Today's Drawing Challenge: Draw your family doing something fun! 🎨' — bright colorful friendly app UI design",
            "Photorealistic, 9:16 vertical portrait, parent and child drawing together at a kitchen table, both intensely focused, pencils and crayons out, warm family bonding moment, golden light",
        ]
    },
    {
        "theme": "Trust_and_Safety",
        "prompts": [
            "Photorealistic, 9:16 vertical portrait, mother with young child on her lap both looking at a colorful tablet app together, warm cozy living room light, trust love and connection",
            "Photorealistic, 9:16 vertical portrait, child's bedroom wall covered floor to ceiling in their own drawings — creative, colorful, joyful — seen from the doorway, warm afternoon sun streaming in",
            "Photorealistic, 9:16 vertical portrait, a child's crayon drawing of their family all holding hands in a row, bright rainbow colors, a red heart drawn in the corner — pure innocent love",
            "Photorealistic, 9:16 vertical portrait, father carefully framing his child's drawing on the wall, young child standing beside him watching proudly, warm indoor evening light, tender father-child moment",
        ]
    },
    {
        "theme": "Urgency_and_Curiosity",
        "prompts": [
            "Photorealistic, 9:16 vertical portrait, mother looking visibly shocked and covering her mouth while reading her phone, child's drawing visible on the table in front of her, dramatic warm lighting, intense authentic reaction",
            "Photorealistic, 9:16 vertical portrait, young child sitting alone in a corner of a room quietly drawing, slightly melancholy atmosphere, soft dim warm light, emotionally evocative and meaningful",
            "Photorealistic, 9:16 vertical portrait, visual split showing two parents — one confused holding a drawing, one confident reading an analysis on phone — storytelling composition, clean warm tones",
            "Realistic phone mockup, 9:16 vertical portrait, urgent app notification: 'Your child's drawing today may reveal hidden anxiety — tap to see the full analysis' — clean modern app UI, white background",
        ]
    },
    {
        "theme": "Heartwarming_Moments",
        "prompts": [
            "Photorealistic, 9:16 vertical portrait, grandmother and young grandchild drawing together at a kitchen table, both smiling softly, multi-generational warmth, golden hour window light",
            "Photorealistic, 9:16 vertical portrait, child running across a room to show their drawing to a parent, motion blur on legs, excited expression, joyful candid energy, bright home",
            "Photorealistic, 9:16 vertical portrait, child's simple crayon drawing of a big yellow sun with a smiley face — just the drawing on white paper, warm natural light, pure innocent joy",
            "Photorealistic, 9:16 vertical portrait, parent wiping a tear from their eye while holding their child's drawing, deeply moved, soft intimate warm lighting, beautiful emotional moment",
        ]
    },
    {
        "theme": "Science_and_Credibility",
        "prompts": [
            "Photorealistic, 9:16 vertical portrait, child psychologist standing in front of a large board with many children's drawings pinned to it, analyzing patterns, professional warm clinical office",
            "Photorealistic, 9:16 vertical portrait, close-up of an open research book titled 'Children's Art and Emotional Development' on a warm wooden desk, reading glasses beside it, credible academic setting",
            "Modern illustration-style, 9:16 vertical portrait, a child's colorful drawing with a soft glowing neural network diagram overlaid on top — representing AI analyzing art — clean tech-meets-childhood visual, warm tones",
            "Photorealistic, 9:16 vertical portrait, split image — child drawing freely on one side, smartphone with emotional analysis report on the other — clean modern visual storytelling, warm tones",
        ]
    },
    {
        "theme": "Call_to_Action",
        "prompts": [
            "Realistic product mockup, 9:16 vertical portrait, App Store page for a child development app — colorful icon with crayon and child figure, 4.9 stars, 'Free Download' button, clean white background, professional",
            "Photorealistic, 9:16 vertical portrait, excited young mother downloading an app on her iPhone, one hand on chest, bright natural light, child's colorful drawing visible on table beside her, authentic reaction",
            "Photorealistic, 9:16 vertical portrait, family of three — mother, father, young child — gathered on a couch all looking at one phone together, warm connected family energy, soft indoor light",
            "Realistic app welcome screen mockup, 9:16 vertical portrait, phone showing: 'Welcome to Innerkid. Understand your child through their art. Upload their first drawing 🎨' — clean emotional minimal design",
        ]
    },
]


# ── FAL.AI HTTP HELPERS (urllib — no external deps) ───────────────────────────
def fal_http(method: str, url: str, body: dict | None = None) -> dict:
    data = json.dumps(body).encode() if body else None
    req  = urllib.request.Request(url, data=data, headers={
        "Authorization": f"Key {FAL_KEY}",
        "Content-Type":  "application/json",
    }, method=method)
    with urllib.request.urlopen(req, timeout=90) as resp:
        return json.loads(resp.read().decode())


def fal_submit(endpoint: str, payload: dict) -> dict:
    """Submit to fal.ai queue. Returns dict with request_id, status_url, response_url."""
    r = fal_http("POST", f"https://queue.fal.run/{endpoint}", payload)
    print(f"    ↳ Submitted | id: {r['request_id']}")
    return {"request_id": r["request_id"], "status_url": r["status_url"], "response_url": r["response_url"]}


def fal_poll(jm: dict, max_wait: int = 900) -> dict:
    """Poll using status_url / response_url returned by fal_submit."""
    start = time.time()
    while time.time() - start < max_wait:
        st = fal_http("GET", jm["status_url"])
        status = st.get("status", "")
        if status == "COMPLETED":
            return fal_http("GET", jm["response_url"])
        elif status in ("FAILED", "CANCELLED"):
            raise RuntimeError(f"Job {jm['request_id']} → {status}")
        print(f"    ↳ {status} — retrying in 10s...")
        time.sleep(10)
    raise TimeoutError(f"Job {jm['request_id']} timed out")


def download_file(url: str, dest: Path) -> None:
    dest.parent.mkdir(parents=True, exist_ok=True)
    req = urllib.request.Request(url, headers={"User-Agent": "innerkid-bot/1.0"})
    with urllib.request.urlopen(req, timeout=120) as resp, open(dest, "wb") as f:
        while chunk := resp.read(8192):
            f.write(chunk)
    print(f"    ✅ Saved → {dest.name}")


# ── SRT SUBTITLE GENERATOR ────────────────────────────────────────────────────
def generate_srt(script: str, output_path: Path) -> None:
    words = script.lower().split()
    chunk_size = 7
    chunks = [words[i:i+chunk_size] for i in range(0, len(words), chunk_size)]
    lines = []
    for i, chunk in enumerate(chunks):
        s, e = i * 3, i * 3 + 3
        def ts(sec):
            return f"{sec//3600:02d}:{(sec%3600)//60:02d}:{sec%60:02d},000"
        if len(chunk) > 4:
            mid = len(chunk) // 2
            text = f"{' '.join(chunk[:mid])}\n{' '.join(chunk[mid:])}"
        else:
            text = " ".join(chunk)
        lines += [str(i+1), f"{ts(s)} --> {ts(e)}", text, ""]
    output_path.write_text("\n".join(lines), encoding="utf-8")
    print(f"    📝 SRT → {output_path.name}")


def write_metadata(folder: Path, data: dict) -> None:
    (folder / "metadata.json").write_text(
        json.dumps(data, ensure_ascii=False, indent=2), encoding="utf-8"
    )


# ── STEP 1 · UGC VIDEOS ──────────────────────────────────────────────────────
def produce_ugc_videos():
    print("\n" + "="*60)
    print("🎭  STEP 1: UGC Avatar Videos (5 adet)")
    print("="*60)

    ugc_folder = OUTPUT_ROOT / "UGC Videos"
    ugc_folder.mkdir(parents=True, exist_ok=True)
    hooks = random.sample(HOOKS_POOL, len(AVATARS))
    jobs = []

    for i, avatar in enumerate(AVATARS):
        hook   = hooks[i]
        script = generate_avatar_script(avatar["name"], hook)
        folder = ugc_folder / avatar["name"]
        folder.mkdir(exist_ok=True)

        (folder / "script.txt").write_text(
            f"HOOK:\n{hook}\n\nFULL SCRIPT:\n{script}", encoding="utf-8"
        )
        generate_srt(script, folder / "subtitles.srt")

        print(f"\n  [{i+1}/5] {avatar['name']}")
        print(f"  Hook: \"{hook[:70]}...\"")

        try:
            jm = fal_submit("veed/avatars/text-to-video", {
                "avatar_id": avatar["id"],
                "text": script,
            })
            jobs.append({"avatar": avatar, "jm": jm, "folder": folder, "hook": hook, "script": script})
        except Exception as e:
            print(f"  ❌ Submit error: {e}")

    print("\n  ⏳ Polling UGC jobs...")
    for job in jobs:
        try:
            result  = fal_poll(job["jm"], max_wait=900)
            raw_url = result["video"]["url"]
            raw_dest = job["folder"] / f"{job['avatar']['name'].lower()}_ugc_raw.mp4"
            download_file(raw_url, raw_dest)

            # ── STEP 1b: Burn-in subtitles via fal-ai/workflow-utilities/auto-subtitle ──
            print(f"    🔤 Adding TikTok-style subtitles for {job['avatar']['name']}...")
            try:
                sub_jm = fal_submit("fal-ai/workflow-utilities/auto-subtitle", {
                    "video_url":         raw_url,
                    "language":          "en",
                    "font_name":         "Montserrat",
                    "font_size":         90,
                    "font_weight":       "bold",
                    "font_color":        "white",
                    "highlight_color":   "yellow",
                    "stroke_width":      4,
                    "stroke_color":      "black",
                    "background_color":  "none",
                    "position":          "bottom",
                    "y_offset":          80,
                    "words_per_subtitle": 3,
                    "enable_animation":  True,
                })
                sub_result   = fal_poll(sub_jm, max_wait=600)
                sub_url      = sub_result["video"]["url"]
                captioned_dest = job["folder"] / f"{job['avatar']['name'].lower()}_ugc.mp4"
                download_file(sub_url, captioned_dest)
                print(f"    ✅ Captioned video saved → {captioned_dest.name}")
                final_url = sub_url
                raw_dest.unlink(missing_ok=True)
            except Exception as sub_e:
                print(f"    ⚠️  Subtitle step failed ({sub_e}) — keeping raw video")
                raw_dest.rename(job["folder"] / f"{job['avatar']['name'].lower()}_ugc.mp4")
                final_url = raw_url

            write_metadata(job["folder"], {
                "avatar":    job["avatar"]["name"],
                "avatar_id": job["avatar"]["id"],
                "hook":      job["hook"],
                "script":    job["script"],
                "video_url": final_url,
                "subtitles": "burned-in (Montserrat Bold, white + black stroke, TikTok style)",
                "date":      DATE_LABEL,
                "hashtags":  "#childpsychology #parenting #childdevelopment #kidsart #innerkid #parentingtips #momtok #dadtok #emotionalintelligence #kidsdrawing",
            })
        except Exception as e:
            print(f"  ❌ {job['avatar']['name']}: {e}")

    print("\n  ✅ UGC + Subtitles done!")


# ── STEP 2 · SLIDESHOW IMAGES ─────────────────────────────────────────────────
def produce_slideshow_images():
    print("\n" + "="*60)
    print("🖼️   STEP 2: Slideshow Görseller (15 × 4 = 60 images)")
    print("="*60)

    all_jobs = []

    for idx, theme_data in enumerate(SLIDESHOW_THEMES):
        num    = idx + 1
        folder = OUTPUT_ROOT / f"{num:02d}. Slideshow — {theme_data['theme']}"
        folder.mkdir(parents=True, exist_ok=True)
        print(f"\n  [{num:02d}/15] {theme_data['theme']}")

        for img_idx, prompt in enumerate(theme_data["prompts"]):
            try:
                jm = fal_submit("fal-ai/gpt-image-1.5", {
                    "prompt": prompt,
                    "image_size": "1024x1536",
                    "quality":    "high",
                    "output_format": "png",
                    "num_images": 1,
                })
                all_jobs.append({
                    "num": num,
                    "theme": theme_data["theme"],
                    "img_idx": img_idx,
                    "jm": jm,
                    "dest": folder / f"image_{img_idx+1:02d}.png",
                    "folder": folder,
                })
                time.sleep(0.4)
            except Exception as e:
                print(f"  ❌ Slideshow {num} img {img_idx+1}: {e}")

    print(f"\n  ⏳ Polling {len(all_jobs)} image jobs...")
    seen_folders: set[Path] = set()
    for job in all_jobs:
        try:
            result = fal_poll(job["jm"], max_wait=300)
            url    = result["images"][0]["url"]
            download_file(url, job["dest"])
            if job["folder"] not in seen_folders:
                seen_folders.add(job["folder"])
                write_metadata(job["folder"], {
                    "slideshow_num": job["num"],
                    "theme": job["theme"],
                    "date": DATE_LABEL,
                    "image_size": "1024x1536 (9:16 portrait)",
                    "hashtags": "#childpsychology #kidsart #parenting #childdevelopment #innerkid #momtok #arttherapy #emotionalintelligence #parentingapp #kidsdrawing",
                })
        except Exception as e:
            print(f"  ❌ Slideshow {job['num']} img {job['img_idx']+1}: {e}")

    print("\n  ✅ Slideshow images done!")


# ── DAILY REPORT ──────────────────────────────────────────────────────────────
def write_daily_report():
    report = OUTPUT_ROOT / "daily_report.md"
    report.write_text(f"""# İnnerkid Daily Ad Report — {DATE_LABEL}

## 🎭 UGC Videos (5 adet)
Avatarlar  : Emily · Elena · Jasmine · Marcus · Mira
Model      : veed/avatars/text-to-video (fal.ai)
Format     : 9:16 vertical

## 🖼️ Slideshows (15 klasör × 4 görsel = 60 image)
Model      : fal-ai/gpt-image-1.5
Size       : 1024 × 1536 (portrait, ~9:16)
Quality    : medium

## 🎯 Hook Kategorileri
• Curiosity Gap   — "most parents miss this completely"
• Authority       — "I've worked with hundreds of kids"
• Pattern Interrupt — "Stop ignoring the signs"
• Personal Story  — "I became a psychologist because of a drawing"
• Numbered List   — "3 signs your child's drawing means..."

## 📌 Önerilen Hashtags
#childpsychology #parenting #childdevelopment #kidsart #innerkid
#parentingtips #childmindset #momtok #dadtok #emotionalintelligence
#arttherapy #kidsdrawing #parentingapp #toddlerlife #raisingsmartkids

## 📁 Klasör Yapısı
{DATE_LABEL} Videoları/
├── UGC Videos/
│   ├── Emily/       → emily_ugc.mp4 + script.txt + subtitles.srt + metadata.json
│   ├── Elena/
│   ├── Jasmine/
│   ├── Marcus/
│   └── Mira/
├── 01. Slideshow — Child_Drawing_Emotions/
│   ├── image_01.png … image_04.png
│   └── metadata.json
├── 02. Slideshow — Parent_Child_Connection/
│   └── ...
└── 15. Slideshow — Call_to_Action/
""", encoding="utf-8")
    print(f"\n  📊 Report → daily_report.md")


# ── MAIN ──────────────────────────────────────────────────────────────────────
def main():
    print("\n" + "🚀 " * 20)
    print(f"  İNNERKID AD AUTOMATION — {DATE_LABEL}")
    print("🚀 " * 20 + "\n")

    OUTPUT_ROOT.mkdir(parents=True, exist_ok=True)
    print(f"📁 Output: {OUTPUT_ROOT}\n")

    try:
        produce_ugc_videos()
    except Exception as e:
        print(f"\n❌ UGC step crashed: {e}")

    try:
        produce_slideshow_images()
    except Exception as e:
        print(f"\n❌ Slideshow step crashed: {e}")

    write_daily_report()

    print("\n" + "✅ " * 20)
    print(f"  DONE! Videos ready in:\n  {OUTPUT_ROOT}")
    print("✅ " * 20 + "\n")


if __name__ == "__main__":
    main()
